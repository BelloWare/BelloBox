#!/usr/bin/env python3
"""Reproduce reviewed recording LOC without building or editing the repository."""
import argparse, collections, difflib, hashlib, json, subprocess, tarfile
from pathlib import Path

BASELINE = '1f5874ce741b8de21fa09c747a5bada7488e2982'
TREE = 'f797c0e9c7956ef842a4bb6a4dc769bb932ee897'
BASE_COUNTS = {'production':50053, 'support':28388, 'benchmark':105}
REVIEWED_RANGE_SHA = '3e64c61f1d6e9f8ed6370ab002f8551719031a87ff0a6f666daddebbf57943c7'
CATS = ('production','support','benchmark')

def sha(data): return hashlib.sha256(data).hexdigest()
def need(ok, detail):
    if not ok: raise AssertionError(detail)
def load(path): return json.loads(path.read_text())
def inventory(root):
    # Publication Rust source is restricted to first-party crates. Evidence .rs.txt,
    # archive copies, target artifacts and external harness copies are not source.
    return {p.relative_to(root).as_posix(): p.read_bytes()
            for p in sorted((root/'rust/crates').rglob('*.rs'))
            if not any(x in ('target','.git','vendor') for x in p.relative_to(root).parts)}

def classified(data, ranges):
    lines=data.decode('utf-8').splitlines(); support=set(); previous=0
    for a,b in ranges:
        need(1<=a<=b<=len(lines) and a>previous, ('range-bounds-or-overlap',a,b,len(lines)))
        support.update(range(a,b+1)); previous=b
    return [(i,s.strip(),'support' if i in support else 'production')
            for i,s in enumerate(lines,1) if s.strip()]

def runs(rows):
    result=[]
    for i,text,cat in rows:
        if result and result[-1]['category']==cat and result[-1]['end']+1==i:
            result[-1]['end']=i; result[-1]['nonblank']+=1
        else: result.append({'start':i,'end':i,'category':cat,'nonblank':1})
    return result

def partitions(data, ranges):
    lines=data.decode().splitlines(); support={i for a,b in ranges for i in range(a,b+1)}
    result=[]
    for i,line in enumerate(lines,1):
        cat='support' if i in support else 'production'
        if not result or result[-1]['category']!=cat:
            result.append({'start':i,'end':i,'category':cat,'nonblank':0})
        span=result[-1];span['end']=i;span['nonblank']+=bool(line.strip())
    for span in result:
        span['physical_span_text_sha256']=sha('\n'.join(lines[span['start']-1:span['end']]).encode())
    return result

def describe(path, old, new, review):
    left=classified(old,review['before_support_ranges']);right=classified(new,review['after_support_ranges'])
    metrics={f'{verb}_{cat}':0 for verb in ('added','removed') for cat in ('production','support')}
    metrics.update(support_to_production=0,production_to_support=0,unchanged_production=0,unchanged_support=0)
    changes=[]
    for tag,a,b,c,d in difflib.SequenceMatcher(a=[x[1] for x in left],b=[x[1] for x in right],autojunk=False).get_opcodes():
        if tag=='equal':
            pairs=[]
            for l,r in zip(left[a:b],right[c:d]):
                status='unchanged_'+l[2] if l[2]==r[2] else l[2]+'_to_'+r[2]
                metrics[status]+=1
                if pairs and pairs[-1]['status']==status and pairs[-1]['before_end']+1==l[0] and pairs[-1]['after_end']+1==r[0]:
                    pairs[-1]['before_end']=l[0];pairs[-1]['after_end']=r[0];pairs[-1]['nonblank']+=1
                else:pairs.append({'status':status,'before_start':l[0],'before_end':l[0],'after_start':r[0],'after_end':r[0],'nonblank':1})
            changes.extend(pairs)
        else:
            for verb,rows in [('removed',left[a:b]),('added',right[c:d])]:
                for span in runs(rows):
                    metrics[verb+'_'+span['category']]+=span['nonblank']
                    changes.append({'status':verb, 'side':'before' if verb=='removed' else 'after',**span})
    counts=lambda rows:{cat:sum(x[2]==cat for x in rows) for cat in ('production','support')}
    bc,ac=counts(left),counts(right)
    metrics.update({cat+'_delta':ac[cat]-bc[cat] for cat in bc})
    need(metrics['production_delta']==metrics['added_production']-metrics['removed_production']+metrics['support_to_production']-metrics['production_to_support'],(path,'production-equation'))
    need(metrics['support_delta']==metrics['added_support']-metrics['removed_support']-metrics['support_to_production']+metrics['production_to_support'],(path,'support-equation'))
    return {'path':path,'before_sha256':sha(old),'after_sha256':sha(new),
        'before_nonblank':len(left),'after_nonblank':len(right),'before_counts':bc,'after_counts':ac,
        'before_support_ranges':review['before_support_ranges'],'after_support_ranges':review['after_support_ranges'],
        'before_complete_classification':partitions(old,review['before_support_ranges']),
        'after_complete_classification':partitions(new,review['after_support_ranges']),
        'metrics':metrics,'per_span_delta_including_unchanged':changes,'notes':review.get('notes',[])}

def verify(root,repo=None,binary=None):
    sealed=load(root/'audit-inputs.json')
    need(sealed['baseline_commit']==BASELINE and sealed['baseline_tree']==TREE and sealed['baseline_counts']==BASE_COUNTS,'fixed-baseline')
    for path,digest in sealed['input_hashes'].items(): need(sha((root/path).read_bytes())==digest,('sealed-input',path))
    ranges_bytes=(root/'reviewed-ranges.json').read_bytes()
    need(sha(ranges_bytes)==REVIEWED_RANGE_SHA,'reviewed-semantic-range-seal')
    ranges=json.loads(ranges_bytes)['files']; inv=load(root/'rust-inventory.json')
    before=inventory(root/'before');after=inventory(root/'after')
    expected_before={i['path']:i['before_sha256'] for i in inv if i['before_exists']}
    expected_after={i['path']:i['after_sha256'] for i in inv if i['after_exists']}
    need({p:sha(d) for p,d in before.items()}==expected_before,'before-source-inventory')
    need({p:sha(d) for p,d in after.items()}==expected_after,'after-source-inventory')
    changed={p for p in set(before)|set(after) if before.get(p)!=after.get(p)}
    need(changed==set(ranges),'exact-changed-source-scope')
    # Whole-tree physical sum is independent of inherited baseline category totals.
    old_total=sum(sum(bool(s.strip()) for s in d.splitlines()) for d in before.values())
    new_total=sum(sum(bool(s.strip()) for s in d.splitlines()) for d in after.values())
    need(old_total==sum(BASE_COUNTS.values()),'baseline-physical-total')
    entries=[describe(p,before.get(p,b''),after.get(p,b''),ranges[p]) for p in sorted(changed)]
    sums=dict(collections.Counter({k:0 for k in entries[0]['metrics']}))
    for entry in entries:
        for k,v in entry['metrics'].items():sums[k]+=v
    result={c:BASE_COUNTS[c]+sums.get(c+'_delta',0) for c in CATS}
    need(sum(result.values())==new_total,'result-physical-total')
    want=load(root/'loc-recording-checkpoint.json')
    need(want['files']==entries,'per-file-and-per-span-ledger')
    need(want['totals']==sums and want['result_counts']==result,'totals-and-result-counts')
    need(want['baseline_counts']==BASE_COUNTS and want['baseline_commit']==BASELINE and want['baseline_tree']==TREE,'ledger-baseline')
    publication=load(root/'publication-manifest.json')
    need(publication['base_commit']==BASELINE and publication['base_tree']==TREE,'publication-baseline')
    pub_rs={f['path']:f for f in publication['files'] if f['path'].endswith('.rs')}
    need(set(pub_rs)==changed,'publication-rust-scope')
    for path,f in pub_rs.items():
        need(f['after_sha256']==sha(after[path]),('publication-after-hash',path))
        need(f['before_sha256']==(sha(before[path]) if path in before else None),('publication-before-hash',path))
    benchmark_paths=[p for p in before if '/benches/' in p or '/examples/' in p]
    need(benchmark_paths==sealed['benchmark_paths'],'benchmark-scope')
    need(all(before[p]==after[p] for p in benchmark_paths),'benchmark-source-unchanged')
    need(sum(sum(bool(s.strip()) for s in before[p].splitlines()) for p in benchmark_paths)==105,'benchmark-physical-total')
    # Exact original 179 inputs, not a retroactively enlarged before/after claim.
    bp=root/'build-provenance';m=load(bp/'source-inputs.json')
    mb=load(bp/'source-inputs-before.json');ma=load(bp/'source-inputs-after.json')
    need(mb==ma and m['files']==mb['files'] and len(m['files'])==179,'original179-before-after')
    with tarfile.open(bp/'source-snapshot.tar.gz') as t:
        names=t.getnames();need(len(names)==len(set(names))==176,'source-archive-members')
        for f in m['files']:
            p=f['path']
            data=(root/sealed['external_input_copies'][p]).read_bytes() if p.startswith('/') else t.extractfile(p).read()
            need(sha(data)==f['sha256'],('frozen179-input',p))
            if p.endswith('.rs') and not p.startswith('/'):need(after[p]==data,('source-to-build-input',p))
        need({f['path'] for f in m['files'] if f['path'].endswith('.rs')}==set(after),'all163-rust-inputs')
    if repo:
        actual=inventory(repo);need({p:sha(d) for p,d in actual.items()}==expected_after,'live-source-inventory')
        tree=subprocess.check_output(['git','-C',str(repo),'rev-parse',BASELINE+'^{tree}']).decode().strip()
        need(tree==TREE,'published-baseline-tree')
        treepaths=subprocess.check_output(['git','-C',str(repo),'ls-tree','-r','--name-only',BASELINE]).decode().splitlines()
        need({p for p in treepaths if p.endswith('.rs')}==set(before),'published-rust-scope')
        for p,data in before.items():
            actual=subprocess.check_output(['git','-C',str(repo),'show',BASELINE+':'+p]);need(actual==data,('published-before-blob',p))
        for f in m['files']:
            if not f['path'].startswith('/'):need(sha((repo/f['path']).read_bytes())==f['sha256'],('live-frozen-input',f['path']))
    ba=load(bp/'later-include-input-audit.json')
    need(ba['original_input_count']==179 and ba['later_audited_input_count']==181,'later-include-disclosure')
    if binary:
        data=binary.read_bytes();need(sha(data)==m['binary_sha256'],'frozen-binary')
        if repo:
            for f in ba['additional_inputs']:
                inc=(repo/f['path']).read_bytes();need(sha(inc)==f['sha256'] and inc in data,('later-include-embedded',f['path']))
    return {'verified':True,'baseline_commit':BASELINE,'baseline_tree':TREE,'before_rust_files':len(before),'after_rust_files':len(after),
        'changed_files':len(entries),'unchanged_files':len(after)-len(entries),'physical_before':old_total,'physical_after':new_total,
        'baseline_counts':BASE_COUNTS,'totals':sums,'result_counts':result,'frozen_inputs_verified':179,
        'live_source_verified':repo is not None,'binary_verified':binary is not None,
        'shared_workbench_counted_once':True,'archived_and_external_harness_copies_excluded':True}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--audit-dir',type=Path,default=Path(__file__).resolve().parent)
    p.add_argument('--repo',type=Path);p.add_argument('--binary',type=Path);a=p.parse_args()
    print(json.dumps(verify(a.audit_dir.resolve(),a.repo,a.binary),indent=2))
