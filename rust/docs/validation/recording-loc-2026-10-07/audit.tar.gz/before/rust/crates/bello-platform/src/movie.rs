//! Portable contracts for explicit local movie decoding on a caller-owned worker.
//!
//! Reconstructed after the previous execution workspace was lost. The actual
//! typed macOS implementation compiles normally behind an explicit closed gate.
//! Production entry points remain Unavailable on every platform, before I/O.
//! No application route or native capability is enabled by this checkpoint.
//! This is not screen recording, an importer UI or GIF decoding. Intended frames
//! feed the existing Rust GIF encoder. No blanket hardware acceleration guarantee.
#[cfg(target_os = "macos")]
mod macos;
#[cfg(any(target_os = "macos", test))]
mod retirement;
#[cfg(unix)]
mod source_file;
#[cfg(test)]
mod tests;

use std::{
    fmt,
    marker::PhantomData,
    path::Path,
    rc::Rc,
    sync::{
        atomic::{AtomicBool, Ordering},
        Arc,
    },
    time::Duration,
};

/// Production availability is deliberately disabled pending native CI evidence.
/// macOS unit tests compile and exercise the actual implementation below.
pub const NATIVE_MOVIE_READER_IMPLEMENTED: bool = false;
pub const MAX_MOVIE_FRAME_PIXELS: u64 = 8_388_608;
pub const MAX_MOVIE_FRAME_DIMENSION: u32 = 16_384;
pub const MAX_PIXEL_BUFFER_BYTES: usize = 64 * 1024 * 1024;
pub const MAX_MOVIE_SAMPLES: usize = 30_000;
pub const METADATA_TIMEOUT: Duration = Duration::from_secs(30);

/// Cross-thread cancellation contains no native object or callback. A future
/// native reader observes it between serialized calls; it cannot forcibly
/// interrupt copyNextSampleBuffer, nor call cancelReading concurrently with it.
#[derive(Clone, Debug, Default)]
pub struct MovieCancellation(Arc<AtomicBool>);
impl MovieCancellation {
    pub fn cancel(&self) {
        self.0.store(true, Ordering::Release);
    }
    pub fn is_cancelled(&self) -> bool {
        self.0.load(Ordering::Acquire)
    }
    pub fn check(&self) -> MovieResult<()> {
        if self.is_cancelled() {
            Err(MovieError::Cancelled)
        } else {
            Ok(())
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq)]
pub struct MovieInfo {
    pub duration: f64,
    /// Exact preferred-transform bounding dimensions; frame dimensions round them.
    pub display_width: f64,
    pub display_height: f64,
    pub nominal_frame_rate: f64,
}

/// Bounded source-time range from a core GIF plan. Decoder tolerance is one output
/// frame. Sampling, final trim cut and GIF delay allocation remain core-owned.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct MovieReadRange {
    start: f64,
    end: f64,
    frame_interval: f64,
}
impl MovieReadRange {
    pub fn new(start: f64, end: f64, frame_interval: f64) -> MovieResult<Self> {
        if !start.is_finite()
            || !end.is_finite()
            || !frame_interval.is_finite()
            || start < 0.
            || end - start < 0.05
            || end - start > 120.000_001
            || !(0.05..=0.2).contains(&frame_interval)
        {
            return Err(MovieError::InvalidRange);
        }
        Ok(Self {
            start,
            end,
            frame_interval,
        })
    }
    pub fn start(&self) -> f64 {
        self.start
    }
    pub fn end(&self) -> f64 {
        self.end
    }
    pub fn decode_duration(&self) -> f64 {
        self.end - self.start + self.frame_interval
    }
}

/// Owned tightly packed, top-left/y-down opaque RGBA. Debug excludes pixels;
/// into_parts moves the allocation into a caller's core frame without a copy.
pub struct MovieFrame {
    presentation_seconds: f64,
    width: u32,
    height: u32,
    rgba: Vec<u8>,
}
impl MovieFrame {
    pub fn presentation_seconds(&self) -> f64 {
        self.presentation_seconds
    }
    pub fn size(&self) -> (u32, u32) {
        (self.width, self.height)
    }
    pub fn into_parts(self) -> (f64, u32, u32, Vec<u8>) {
        (
            self.presentation_seconds,
            self.width,
            self.height,
            self.rgba,
        )
    }
    #[cfg(any(target_os = "macos", test))]
    fn new(presentation_seconds: f64, width: u32, height: u32, rgba: Vec<u8>) -> MovieResult<Self> {
        let bytes = frame_bytes(width, height)?;
        if !presentation_seconds.is_finite() || presentation_seconds < 0. {
            return Err(MovieError::InvalidTimestamp);
        }
        if bytes != rgba.len() {
            return Err(MovieError::InvalidFrame);
        }
        Ok(Self {
            presentation_seconds,
            width,
            height,
            rgba,
        })
    }
}
impl fmt::Debug for MovieFrame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("MovieFrame")
            .field("presentation_seconds", &self.presentation_seconds)
            .field("size", &self.size())
            .field("rgba_bytes", &self.rgba.len())
            .finish()
    }
}

/// One owned, pointer-free selection carried through inspection, seeking and
/// publication. Its retained descriptor detects ordinary path/inode/length/time
/// changes; URL-based AVFoundation does not consume frozen bytes. Atomic swaps
/// and change-and-revert between checks are not an immutability guarantee.
#[derive(Clone, Debug)]
pub struct SelectedMovie {
    #[cfg(unix)]
    source: Arc<source_file::SourceFile>,
    #[cfg(any(test, feature = "movie-fixtures"))]
    generated: bool,
    #[cfg(feature = "movie-fixtures")]
    _fixture: Option<Arc<GeneratedDirectory>>,
}
impl SelectedMovie {
    pub fn path(&self) -> &Path {
        #[cfg(unix)]
        {
            self.source.path()
        }
        #[cfg(not(unix))]
        {
            Path::new("")
        }
    }
    pub fn verify(&self) -> MovieResult<()> {
        #[cfg(unix)]
        {
            self.source.verify()
        }
        #[cfg(not(unix))]
        {
            Err(MovieError::Unavailable)
        }
    }
    fn admitted(&self) -> bool {
        #[cfg(any(test, feature = "movie-fixtures"))]
        if self.generated {
            return true;
        }
        NATIVE_MOVIE_READER_IMPLEMENTED
    }
    #[cfg(unix)]
    fn select(path: &Path) -> MovieResult<Self> {
        Ok(Self {
            source: Arc::new(source_file::SourceFile::open(path)?),
            #[cfg(any(test, feature = "movie-fixtures"))]
            generated: false,
            #[cfg(feature = "movie-fixtures")]
            _fixture: None,
        })
    }
}
impl PartialEq for SelectedMovie {
    fn eq(&self, other: &Self) -> bool {
        #[cfg(unix)]
        {
            Arc::ptr_eq(&self.source, &other.source)
        }
        #[cfg(not(unix))]
        {
            let _ = other;
            false
        }
    }
}
/// Paused source-frame request, independent of export's fps/0.05–120s limits.
/// Reads at most two seconds before the requested time and 250ms after it.
/// FrameUnavailable means no acceptable reader sample; coded gaps may be filled.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct MovieSeek {
    seconds: f64,
}
impl MovieSeek {
    pub fn new(seconds: f64) -> MovieResult<Self> {
        if !seconds.is_finite() || seconds < 0. {
            return Err(MovieError::InvalidRange);
        }
        Ok(Self { seconds })
    }
    fn range(self, duration: f64) -> MovieResult<(f64, f64, f64)> {
        if !duration.is_finite() || duration <= 0. || self.seconds > duration {
            return Err(MovieError::InvalidRange);
        }
        // End denotes the final displayed sample, never a nonexistent EOF frame.
        let target = self.seconds.min((duration - 1e-9).max(0.));
        let start = (target - 2.).max(0.);
        let end = (target + 0.25).min(duration);
        Ok((start, (end - start).max(1. / 600.), target))
    }
}
pub struct MovieAsset {
    #[cfg(target_os = "macos")]
    native: macos::Asset,
    info: MovieInfo,
    selected: SelectedMovie,
    cancellation: MovieCancellation,
    _thread_bound: PhantomData<Rc<()>>,
}
impl MovieAsset {
    /// Closed before all filesystem/native work, including ordinary macOS tests.
    pub fn open(path: &Path, cancellation: MovieCancellation) -> MovieResult<Self> {
        if !NATIVE_MOVIE_READER_IMPLEMENTED {
            return Err(MovieError::Unavailable);
        }
        #[cfg(unix)]
        {
            Self::open_selected(SelectedMovie::select(path)?, cancellation)
        }
        #[cfg(not(unix))]
        {
            let _ = (path, cancellation);
            Err(MovieError::Unavailable)
        }
    }
    pub fn open_selected(
        selected: SelectedMovie,
        cancellation: MovieCancellation,
    ) -> MovieResult<Self> {
        if !selected.admitted() {
            return Err(MovieError::Unavailable);
        }
        #[cfg(target_os = "macos")]
        {
            cancellation.check()?;
            selected.verify()?;
            let native = macos::Asset::open(selected.source.clone(), cancellation.clone())?;
            Ok(Self {
                info: native.info(),
                selected,
                cancellation,
                native,
                _thread_bound: PhantomData,
            })
        }
        #[cfg(not(target_os = "macos"))]
        {
            let _ = (selected, cancellation);
            Err(MovieError::Unavailable)
        }
    }
    pub fn info(&self) -> MovieInfo {
        self.info
    }
    pub fn selected_source(&self) -> SelectedMovie {
        self.selected.clone()
    }
    pub fn source_path(&self) -> &Path {
        self.selected.path()
    }
    pub fn cancellation(&self) -> MovieCancellation {
        self.cancellation.clone()
    }
    pub fn reader(self, range: MovieReadRange) -> MovieResult<MovieReader> {
        #[cfg(target_os = "macos")]
        {
            self.cancellation.check()?;
            if range.start >= self.info.duration || range.end > self.info.duration + 0.001 {
                return Err(MovieError::InvalidRange);
            }
            let native = self.native.reader(range.start(), range.decode_duration())?;
            Ok(MovieReader {
                native,
                info: self.info,
                selected: self.selected,
                cancellation: self.cancellation,
                _thread_bound: PhantomData,
            })
        }
        #[cfg(not(target_os = "macos"))]
        {
            let _ = range;
            Err(MovieError::Unavailable)
        }
    }
    /// Single paused frame. Last PTS at/before target wins; when the first sample
    /// is later, show it only within the bounded window and report its actual PTS.
    /// This is bounded decoder seeking, not exact AVPlayer/continuous playback.
    pub fn seek(self, seek: MovieSeek) -> MovieResult<MovieFrame> {
        let (start, duration, target) = seek.range(self.info.duration)?;
        #[cfg(target_os = "macos")]
        {
            let mut reader = self.native.reader(start, duration)?;
            let mut current = None;
            while let Some(frame) = reader.next_frame(&|| false)? {
                let pts = frame.presentation_seconds();
                if pts < start {
                    continue;
                }
                if pts > start + duration {
                    break;
                }
                if pts > target {
                    if current.is_none() {
                        current = Some(frame);
                    }
                    break;
                }
                current = Some(frame);
            }
            reader.finish(&|| false)?;
            current.ok_or(MovieError::FrameUnavailable)
        }
        #[cfg(not(target_os = "macos"))]
        {
            let _ = (start, duration, target);
            Err(MovieError::Unavailable)
        }
    }
}
pub struct MovieReader {
    #[cfg(target_os = "macos")]
    native: macos::Reader,
    info: MovieInfo,
    selected: SelectedMovie,
    cancellation: MovieCancellation,
    _thread_bound: PhantomData<Rc<()>>,
}
impl MovieReader {
    pub fn info(&self) -> MovieInfo {
        self.info
    }
    pub fn source_path(&self) -> &Path {
        self.selected.path()
    }
    pub fn cancellation(&self) -> MovieCancellation {
        self.cancellation.clone()
    }
    /// All native reads/cancellation/finalization remain serialized on this owner.
    pub fn next_frame(
        &mut self,
        should_cancel: impl Fn() -> bool,
    ) -> MovieResult<Option<MovieFrame>> {
        #[cfg(target_os = "macos")]
        {
            self.native.next_frame(&should_cancel)
        }
        #[cfg(not(target_os = "macos"))]
        {
            let _ = should_cancel;
            Err(MovieError::Unavailable)
        }
    }
    /// Checks terminal native status and original source immediately before staged
    /// publication. A deliberately trimmed reader may still be Reading; no EOF
    /// drain is required. Native cancellation never races a sample read.
    pub fn finish(&mut self, should_cancel: impl Fn() -> bool) -> MovieResult<()> {
        #[cfg(target_os = "macos")]
        {
            self.native.finish(&should_cancel)
        }
        #[cfg(not(target_os = "macos"))]
        {
            let _ = should_cancel;
            Err(MovieError::Unavailable)
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum MovieError {
    Unavailable,
    Busy,
    Cancelled,
    TimedOut,
    InvalidSource,
    SourceChanged,
    InvalidRange,
    InvalidMetadata,
    InvalidTimestamp,
    InvalidFrame,
    FrameUnavailable,
    LimitExceeded,
    NoVideoTrack,
    ProtectedContent,
    MetadataFailed,
    DecodeFailed,
    NativeFailure,
    Io,
}
pub type MovieResult<T> = Result<T, MovieError>;
impl fmt::Display for MovieError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(match self {
            Self::Unavailable => "Native local movie decoding is unavailable on this platform.",
            Self::Busy => "Another native movie job is still active.",
            Self::Cancelled => "Movie decoding was cancelled.",
            Self::TimedOut => "Movie metadata did not finish loading within the limit.",
            Self::InvalidSource => "Choose an existing local regular movie file.",
            Self::SourceChanged => "The movie source changed while it was being read.",
            Self::InvalidRange => "The movie read range is invalid or exceeds the GIF limits.",
            Self::InvalidMetadata => "The movie has invalid or unsupported display metadata.",
            Self::InvalidTimestamp => {
                "The movie has invalid or out-of-order presentation timestamps."
            }
            Self::FrameUnavailable => "No source frame is available in the bounded seek window.",
            Self::InvalidFrame => "The movie decoder returned invalid frame storage.",
            Self::LimitExceeded => "The movie exceeds a bounded frame, buffer or sample limit.",
            Self::NoVideoTrack => "The movie has no video track.",
            Self::ProtectedContent => "Protected movie content cannot be decoded.",
            Self::MetadataFailed => "Movie metadata could not be loaded.",
            Self::DecodeFailed => "The movie decoder failed before reaching the end of its range.",
            Self::NativeFailure => "The native movie framework could not complete the operation.",
            Self::Io => "The local movie file could not be read.",
        })
    }
}
impl std::error::Error for MovieError {}

#[cfg(any(target_os = "macos", test))]
fn frame_bytes(width: u32, height: u32) -> MovieResult<usize> {
    let pixels = u64::from(width)
        .checked_mul(u64::from(height))
        .ok_or(MovieError::LimitExceeded)?;
    if width == 0
        || height == 0
        || width > MAX_MOVIE_FRAME_DIMENSION
        || height > MAX_MOVIE_FRAME_DIMENSION
        || pixels > MAX_MOVIE_FRAME_PIXELS
    {
        return Err(MovieError::LimitExceeded);
    }
    usize::try_from(pixels.checked_mul(4).ok_or(MovieError::LimitExceeded)?)
        .map_err(|_| MovieError::LimitExceeded)
}
#[cfg(any(target_os = "macos", test))]
#[derive(Clone, Copy, Debug, PartialEq)]
struct DisplayGeometry {
    min_x: f64,
    min_y: f64,
    width: u32,
    height: u32,
    extent_width: f64,
    extent_height: f64,
}
#[cfg(any(target_os = "macos", test))]
fn display_geometry(
    natural_width: f64,
    natural_height: f64,
    transform: [f64; 6],
) -> MovieResult<DisplayGeometry> {
    if !natural_width.is_finite()
        || !natural_height.is_finite()
        || natural_width < 1.
        || natural_height < 1.
        || !transform.iter().all(|v| v.is_finite())
    {
        return Err(MovieError::InvalidMetadata);
    }
    if natural_width > f64::from(MAX_MOVIE_FRAME_DIMENSION)
        || natural_height > f64::from(MAX_MOVIE_FRAME_DIMENSION)
    {
        return Err(MovieError::LimitExceeded);
    }
    frame_bytes(natural_width.round() as u32, natural_height.round() as u32)?;
    let [a, b, c, d, tx, ty] = transform;
    let determinant = a * d - b * c;
    if !determinant.is_finite() || determinant.abs() < 1e-12 {
        return Err(MovieError::InvalidMetadata);
    }
    let (mut min_x, mut min_y, mut max_x, mut max_y) = (
        f64::INFINITY,
        f64::INFINITY,
        f64::NEG_INFINITY,
        f64::NEG_INFINITY,
    );
    for (x, y) in [
        (0., 0.),
        (natural_width, 0.),
        (0., natural_height),
        (natural_width, natural_height),
    ] {
        let (x, y) = (a * x + c * y + tx, b * x + d * y + ty);
        if !x.is_finite() || !y.is_finite() {
            return Err(MovieError::InvalidMetadata);
        }
        min_x = min_x.min(x);
        min_y = min_y.min(y);
        max_x = max_x.max(x);
        max_y = max_y.max(y);
    }
    let (extent_width, extent_height) = (max_x - min_x, max_y - min_y);
    if !extent_width.is_finite()
        || !extent_height.is_finite()
        || extent_width < 1.
        || extent_height < 1.
        || extent_width > f64::from(MAX_MOVIE_FRAME_DIMENSION)
        || extent_height > f64::from(MAX_MOVIE_FRAME_DIMENSION)
    {
        return Err(MovieError::LimitExceeded);
    }
    let (width, height) = (extent_width.round() as u32, extent_height.round() as u32);
    frame_bytes(width, height)?;
    Ok(DisplayGeometry {
        min_x,
        min_y,
        width,
        height,
        extent_width,
        extent_height,
    })
}
#[cfg(any(target_os = "macos", test))]
fn validate_pixel_storage(
    width: u32,
    height: u32,
    stride: usize,
    data_size: usize,
) -> MovieResult<()> {
    frame_bytes(width, height)?;
    let row = (width as usize)
        .checked_mul(4)
        .ok_or(MovieError::LimitExceeded)?;
    // CG storage requires the complete final padded row, not just visible pixels.
    let extent = stride
        .checked_mul(height as usize)
        .ok_or(MovieError::LimitExceeded)?;
    if stride < row || extent > data_size {
        return Err(MovieError::InvalidFrame);
    }
    if data_size > MAX_PIXEL_BUFFER_BYTES || extent > MAX_PIXEL_BUFFER_BYTES {
        return Err(MovieError::LimitExceeded);
    }
    Ok(())
}

/// Nondefault cross-crate CI seam: writes its own fixed generated movie. It cannot
/// open a caller-specified file and does not alter ordinary admission globally.
#[cfg(all(target_os = "macos", feature = "movie-fixtures"))]
#[derive(Clone, Copy, Debug)]
pub enum GeneratedOrientation {
    Landscape,
    Portrait,
    Mirrored,
}
#[cfg(feature = "movie-fixtures")]
#[derive(Debug)]
struct GeneratedDirectory(std::path::PathBuf);
#[cfg(feature = "movie-fixtures")]
impl Drop for GeneratedDirectory {
    fn drop(&mut self) {
        let _ = std::fs::remove_dir_all(&self.0);
    }
}
#[cfg(all(target_os = "macos", feature = "movie-fixtures"))]
pub fn generated_movie(orientation: GeneratedOrientation) -> MovieResult<SelectedMovie> {
    generated_movie_case(orientation, GeneratedTiming::Regular)
}
#[cfg(all(target_os = "macos", feature = "movie-fixtures"))]
#[derive(Clone, Copy, Debug)]
pub enum GeneratedTiming {
    Regular,
    Short,
    SparseLong,
    DelayedFirst,
}
#[cfg(all(target_os = "macos", feature = "movie-fixtures"))]
pub fn generated_movie_case(
    orientation: GeneratedOrientation,
    timing: GeneratedTiming,
) -> MovieResult<SelectedMovie> {
    use objc2_core_foundation::CGAffineTransform;
    use std::os::unix::fs::DirBuilderExt;
    static NEXT: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);
    let path = std::env::temp_dir().join(format!(
        "bellobox-owned-movie-{}-{}-{}",
        std::process::id(),
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map_err(|_| MovieError::Io)?
            .as_nanos(),
        NEXT.fetch_add(1, Ordering::Relaxed)
    ));
    std::fs::DirBuilder::new()
        .mode(0o700)
        .create(&path)
        .map_err(|_| MovieError::Io)?;
    let directory = Arc::new(GeneratedDirectory(path));
    let path = directory.0.join("generated.mov");
    let transform = match orientation {
        GeneratedOrientation::Landscape => CGAffineTransform {
            a: 1.,
            b: 0.,
            c: 0.,
            d: 1.,
            tx: 0.,
            ty: 0.,
        },
        GeneratedOrientation::Portrait => CGAffineTransform {
            a: 0.,
            b: 1.,
            c: -1.,
            d: 0.,
            tx: 48.,
            ty: 0.,
        },
        GeneratedOrientation::Mirrored => CGAffineTransform {
            a: -1.,
            b: 0.,
            c: 0.,
            d: 1.,
            tx: 64.,
            ty: 0.,
        },
    };
    let (times, delay): (&[f64], f64) = match timing {
        GeneratedTiming::Regular => (&[0., 0.1, 0.2, 0.3], 0.1),
        GeneratedTiming::Short => (&[0.], 0.02),
        GeneratedTiming::SparseLong => (&[0., 130., 130.1], 0.1),
        GeneratedTiming::DelayedFirst => (&[0.1, 0.2, 0.3], 0.1),
    };
    macos::fixtures::write_movie_times(&path, transform, times, delay);
    let mut selected = SelectedMovie::select(&path)?;
    selected.generated = true;
    selected._fixture = Some(directory);
    Ok(selected)
}

#[cfg(all(target_os = "macos", feature = "movie-fixtures"))]
/// Full-range diagnostic for this module's sealed, self-generated movies only.
/// It does not accept a pathname or relax ordinary admission/export range limits.
/// Eight returned frames bound diagnostic storage; normal fixtures contain <=4.
pub fn generated_movie_trace(selected: SelectedMovie) -> MovieResult<Vec<MovieFrame>> {
    if !selected.generated || selected._fixture.is_none() {
        return Err(MovieError::Unavailable);
    }
    let asset = MovieAsset::open_selected(selected, MovieCancellation::default())?;
    let duration = asset.info.duration;
    let mut reader = asset.native.reader(0., duration)?;
    let mut frames = Vec::new();
    while let Some(frame) = reader.next_frame(&|| false)? {
        if frames.len() == 8 {
            return Err(MovieError::LimitExceeded);
        }
        frames.push(frame);
    }
    reader.finish(&|| false)?;
    Ok(frames)
}
