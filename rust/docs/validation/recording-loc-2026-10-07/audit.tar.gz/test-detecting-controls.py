#!/usr/bin/env python3
"""Mutation controls on temporary audit copies only; no builds or repo writes."""
import argparse,importlib.util,json,shutil,tempfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--audit-dir',type=Path,default=Path(__file__).resolve().parent);a=p.parse_args();root=a.audit_dir.resolve()
spec=importlib.util.spec_from_file_location('loc',root/'verify-recording-loc.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
results=[]
def edit_json(r,p,fn):
 f=r/p;x=json.loads(f.read_text());fn(x);f.write_text(json.dumps(x,indent=2)+'\n')
def append(r,p,s):
 f=r/p;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes((f.read_bytes() if f.exists() else b'')+s.encode())
def change(r,p):
 f=r/p;f.write_bytes(f.read_bytes()+b'// tampered physical line\n')
def run(name,mutator,error=None):
 with tempfile.TemporaryDirectory(prefix='recording-loc-control-') as d:
  dest=Path(d)/'audit';shutil.copytree(root,dest)
  mutator(dest)
  try:v.verify(dest)
  except (AssertionError,FileNotFoundError,KeyError) as e:
   message=str(e);passed=error is not None and error in message
   results.append({'name':name,'expected':'reject','passed':passed,'observed':message})
  else:results.append({'name':name,'expected':'accept' if error is None else 'reject','passed':error is None,'observed':'verified'})
run('production-source-addition',lambda r:change(r,'after/rust/crates/bellobox-app/src/shutdown.rs'),'after-source-inventory')
run('support-test-source-addition',lambda r:change(r,'after/rust/crates/bellobox-app/src/shutdown/tests.rs'),'after-source-inventory')
run('unchanged-source-addition',lambda r:change(r,'after/rust/crates/bellobox-app/src/transport.rs'),'after-source-inventory')
run('new-rust-path-not-ledgered',lambda r:append(r,'after/rust/crates/bellobox-app/src/undeclared.rs','fn added() {}\n'),'after-source-inventory')
run('deleted-source-path',lambda r:(r/'after/rust/crates/bellobox-app/src/recording_ui.rs').unlink(),'after-source-inventory')
run('changed-before-source',lambda r:change(r,'before/rust/crates/bellobox-app/src/main.rs'),'before-source-inventory')
run('production-total-tampering',lambda r:edit_json(r,'loc-recording-checkpoint.json',lambda x:x['result_counts'].__setitem__('production',x['result_counts']['production']+1)),'totals-and-result-counts')
run('support-total-tampering',lambda r:edit_json(r,'loc-recording-checkpoint.json',lambda x:x['totals'].__setitem__('support_delta',x['totals']['support_delta']+1)),'totals-and-result-counts')
run('benchmark-total-tampering',lambda r:edit_json(r,'loc-recording-checkpoint.json',lambda x:x['result_counts'].__setitem__('benchmark',106)),'totals-and-result-counts')
run('ledger-support-range-removal',lambda r:edit_json(r,'loc-recording-checkpoint.json',lambda x:x['files'][0].__setitem__('after_support_ranges',[])),'per-file-and-per-span-ledger')
run('unchanged-span-reclassification',lambda r:edit_json(r,'loc-recording-checkpoint.json',lambda x:x['files'][0]['metrics'].__setitem__('unchanged_support',0)),'per-file-and-per-span-ledger')
run('classification-review-range-tampering',lambda r:edit_json(r,'reviewed-ranges.json',lambda x:x['files']['rust/crates/bello-platform/src/movie.rs'].__setitem__('after_support_ranges',[[1,734]])),'reviewed-semantic-range-seal')
run('duplicate-harness-in-production-scope',lambda r:shutil.copyfile(r/'after/rust/crates/bellobox-app/src/shutdown/tests.rs',r/'after/rust/crates/bellobox-app/src/duplicate_focused_harness.rs'),'after-source-inventory')
run('archived-rs-txt-excluded',lambda r:append(r,'after/rust/docs/evidence/source.rs.txt','// archive\nfn archived() {}\n'))
run('external-focused-copy-excluded',lambda r:append(r,'focused-harness/src/tests.rs','// duplicated external focused test\nfn duplicated() {}\n'))
run('build-artifact-rust-excluded',lambda r:append(r,'after/rust/target/generated.rs','fn generated_dependency() {}\n'))
run('comment-only-change-detected',lambda r:append(r,'after/rust/crates/bellobox-core/src/recording/session.rs','// comments count\n'),'after-source-inventory')
run('blank-only-source-drift-detected',lambda r:append(r,'after/rust/crates/bellobox-core/src/recording/session.rs','\n'),'after-source-inventory')
run('baseline-commit-tampering',lambda r:edit_json(r,'audit-inputs.json',lambda x:x.__setitem__('baseline_commit','0'*40)),'fixed-baseline')
run('baseline-count-tampering',lambda r:edit_json(r,'audit-inputs.json',lambda x:x['baseline_counts'].__setitem__('production',50054)),'fixed-baseline')
run('frozen-build-manifest-tampering',lambda r:edit_json(r,'build-provenance/source-inputs.json',lambda x:x['files'][0].__setitem__('sha256','0'*64)),'sealed-input')
run('retroactive-181-input-claim',lambda r:edit_json(r,'build-provenance/later-include-input-audit.json',lambda x:x.__setitem__('original_input_count',181)),'sealed-input')
run('source-archive-tampering',lambda r:append(r,'build-provenance/source-snapshot.tar.gz','x'),'sealed-input')
run('prior-ledger-rewrite',lambda r:append(r,'prior-ledgers/rust/docs/validation/ai-ocr-2026-10-07/loc-review.json',' '),'sealed-input')
summary={'all_passed':all(x['passed'] for x in results),'controls':len(results),'expected_rejections':sum(x['expected']=='reject' for x in results),'expected_acceptances':sum(x['expected']=='accept' for x in results),'results':results,'restored_baseline_verifies':v.verify(root)['verified']}
print(json.dumps(summary,indent=2));raise SystemExit(0 if summary['all_passed'] else 1)
