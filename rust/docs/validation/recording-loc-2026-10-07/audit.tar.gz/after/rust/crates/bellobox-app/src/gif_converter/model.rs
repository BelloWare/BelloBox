//! Source-shaped converter lifecycle. Worker results are generation fenced; an
//! admitted export remains busy until its worker settles, including cancellation.
use super::recording::OwnedRecording;
use bello_platform::movie::{
    MovieAsset, MovieCancellation, MovieInfo, MovieReadRange, MovieReader, MovieSeek, SelectedMovie,
};
use bellobox_core::recording::gif::{
    self, ExportControl, GifError, GifExportOptions, GifExportPlan, GifExportResult, GifSourceInfo,
    ReplacePolicy, SequentialFrameSource,
};
use std::{
    path::PathBuf,
    sync::{
        Arc,
        atomic::{AtomicUsize, Ordering},
    },
};

#[derive(Clone, Debug, PartialEq)]
pub(super) enum Source {
    Movie(PathBuf),
    Recording(OwnedRecording),
    #[cfg(any(test, debug_assertions))]
    Synthetic,
    #[cfg(all(test, feature = "movie-fixtures", target_os = "macos"))]
    Generated(SelectedMovie),
}
impl Source {
    pub fn name(&self) -> String {
        match self {
            Self::Recording(recording) => recording
                .0
                .path()
                .file_name()
                .unwrap_or_default()
                .to_string_lossy()
                .into_owned(),
            Self::Movie(path) => path
                .file_name()
                .unwrap_or_default()
                .to_string_lossy()
                .into_owned(),
            #[cfg(any(test, debug_assertions))]
            Self::Synthetic => "Synthetic color movie (no input file)".into(),
            #[cfg(all(test, feature = "movie-fixtures", target_os = "macos"))]
            Self::Generated(_) => "Generated native movie".into(),
        }
    }
    pub fn inspect(&self, cancellation: MovieCancellation) -> Result<Inspection, String> {
        cancellation.check().map_err(|e| e.to_string())?;
        match self {
            Self::Recording(recording) => {
                recording.0.verify().map_err(|e| e.to_string())?;
                Ok(Inspection {
                    info: info(recording.0.info()),
                    selected: SelectedSource::Recording(recording.clone()),
                })
            }
            Self::Movie(path) => inspect_asset(MovieAsset::open(path, cancellation)),
            #[cfg(any(test, debug_assertions))]
            Self::Synthetic => {
                fixture_delay("INSPECT", &cancellation)?;
                Ok(Inspection {
                    info: synthetic_info(),
                    selected: SelectedSource::Synthetic(Arc::new(())),
                })
            }
            #[cfg(all(test, feature = "movie-fixtures", target_os = "macos"))]
            Self::Generated(selected) => {
                inspect_asset(MovieAsset::open_selected(selected.clone(), cancellation))
            }
        }
    }
}
fn inspect_asset(
    asset: Result<MovieAsset, bello_platform::movie::MovieError>,
) -> Result<Inspection, String> {
    let asset = asset.map_err(|e| e.to_string())?;
    Ok(Inspection {
        info: info(asset.info()),
        selected: SelectedSource::Movie(asset.selected_source()),
    })
}
#[derive(Clone, Debug)]
pub(super) struct Inspection {
    pub info: GifSourceInfo,
    pub selected: SelectedSource,
}
#[derive(Clone, Debug)]
pub(super) enum SelectedSource {
    Movie(SelectedMovie),
    Recording(OwnedRecording),
    #[cfg(any(test, debug_assertions))]
    Synthetic(Arc<()>),
}
pub(super) struct SourceFrame {
    pub png: Vec<u8>,
    pub requested: f64,
    pub actual: f64,
}
impl std::fmt::Debug for SourceFrame {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("SourceFrame")
            .field("requested", &self.requested)
            .field("actual", &self.actual)
            .field("png_bytes", &self.png.len())
            .finish()
    }
}
impl SelectedSource {
    pub fn seek(
        &self,
        seconds: f64,
        cancellation: MovieCancellation,
    ) -> Result<SourceFrame, String> {
        let seek = MovieSeek::new(seconds).map_err(|e| e.to_string())?;
        let (actual, width, height, rgba) = match self {
            Self::Recording(recording) => recording.seek(seconds, cancellation.clone())?,
            Self::Movie(selected) => {
                MovieAsset::open_selected(selected.clone(), cancellation.clone())
                    .and_then(|asset| asset.seek(seek))
                    .map_err(|e| e.to_string())?
                    .into_parts()
            }
            #[cfg(any(test, debug_assertions))]
            Self::Synthetic(owner) => {
                let _ = owner; // Retain the exact inspected selection, even while showing GIF.
                fixture_delay("SEEK", &cancellation)?;
                let index = (seconds.min(3.) * 20.).floor().min(59.) as usize;
                (index as f64 / 20., 320, 180, synthetic_pixels(index))
            }
        };
        cancellation.check().map_err(|e| e.to_string())?;
        let image = image::RgbaImage::from_raw(width, height, rgba)
            .ok_or_else(|| "Invalid movie preview pixels.".to_string())?;
        // A paused preview never allocates a source-sized GPU texture. Native
        // decoding is separately capped at 8,388,608 pixels; opaque codec memory
        // and transient source/resize/PNG allocations are additional.
        let image = image::DynamicImage::ImageRgba8(image).resize(
            width.min(720),
            height.min(720),
            image::imageops::FilterType::Triangle,
        );
        let mut png = std::io::Cursor::new(Vec::new());
        image
            .write_to(&mut png, image::ImageFormat::Png)
            .map_err(|e| e.to_string())?;
        cancellation.check().map_err(|e| e.to_string())?;
        Ok(SourceFrame {
            png: png.into_inner(),
            requested: seconds,
            actual,
        })
    }
}
#[cfg(any(test, debug_assertions))]
fn synthetic_info() -> GifSourceInfo {
    GifSourceInfo {
        duration: 3.,
        display_width: 320.,
        display_height: 180.,
        nominal_frame_rate: 20.,
    }
}
#[cfg(any(test, debug_assertions))]
fn fixture_delay(phase: &str, cancellation: &MovieCancellation) -> Result<(), String> {
    #[cfg(debug_assertions)]
    if let Ok(value) = std::env::var(format!("BELLOBOX_GIF_{phase}_DELAY_MS"))
        && let Ok(ms) = value.parse::<u64>()
    {
        // Deliberately physical, bounded fixture stall. Logical cancellation
        // may arrive here; admission remains held until this worker returns.
        std::thread::sleep(std::time::Duration::from_millis(ms.min(8_000)));
    }
    let _ = phase;
    cancellation.check().map_err(|e| e.to_string())
}

fn info(value: MovieInfo) -> GifSourceInfo {
    GifSourceInfo {
        duration: value.duration,
        display_width: value.display_width,
        display_height: value.display_height,
        nominal_frame_rate: value.nominal_frame_rate,
    }
}
#[derive(Default)]
pub(super) struct Model {
    pub source: Option<Source>,
    pub info: Option<GifSourceInfo>,
    pub selected: Option<SelectedSource>,
    pub options: GifExportOptions,
    pub result: Option<GifExportResult>,
    pub result_revision: u64,
    pub result_loops: bool,
    pub status: String,
    pub error: bool,
    pub generation: u64,
    pub loading: bool,
    pub dialog: bool,
    pub job: Option<Job>,
    metadata_cancel: MovieCancellation,
    closed: bool,
}
pub(super) struct Job {
    pub control: ExportControl,
    pub movie_cancel: MovieCancellation,
    pub progress: Arc<AtomicUsize>,
    pub planned: usize,
    loops: bool,
}
pub(super) struct Work {
    pub generation: u64,
    source: SelectedSource,
    plan: GifExportPlan,
    destination: PathBuf,
    replace: ReplacePolicy,
    pub control: ExportControl,
    pub movie_cancel: MovieCancellation,
    progress: Arc<AtomicUsize>,
}
impl Model {
    pub fn busy(&self) -> bool {
        self.job.is_some() || self.dialog
    }
    pub fn plan(&self) -> Option<GifExportPlan> {
        GifExportPlan::make(self.info?, &self.options).ok()
    }
    pub fn load(&mut self, source: Source) -> Option<(u64, MovieCancellation)> {
        if self.busy() || self.closed {
            return None;
        }
        self.metadata_cancel.cancel();
        self.metadata_cancel = MovieCancellation::default();
        self.generation += 1;
        self.source = Some(source);
        self.info = None;
        self.selected = None;
        self.result = None;
        self.options.trim_start = 0.;
        self.options.trim_end = None;
        self.status = "Reading movie metadata…".into();
        self.error = false;
        self.loading = true;
        Some((self.generation, self.metadata_cancel.clone()))
    }
    pub fn loaded(&mut self, generation: u64, result: Result<Inspection, String>) {
        if self.closed || generation != self.generation || !self.loading {
            return;
        }
        self.loading = false;
        match result {
            Ok(Inspection { info, selected }) => {
                self.selected = Some(selected);
                self.options.trim_end = Some(info.duration.min(gif::MAX_DURATION_SECONDS));
                self.info = Some(info);
                self.status = "Ready. The source is kept after conversion.".into();
            }
            Err(error) => {
                self.status = error;
                self.error = true;
            }
        }
    }
    pub fn begin(&mut self, destination: PathBuf, replace: ReplacePolicy) -> Option<Work> {
        if self.busy() || self.closed {
            return None;
        }
        let source = self.selected.clone()?;
        let plan = self.plan()?;
        self.generation += 1;
        let control = ExportControl::default();
        let movie_cancel = MovieCancellation::default();
        let progress = Arc::new(AtomicUsize::new(0));
        self.job = Some(Job {
            control: control.clone(),
            movie_cancel: movie_cancel.clone(),
            progress: progress.clone(),
            planned: plan.frame_count(),
            loops: plan.loops(),
        });
        self.status = "Encoding GIF locally…".into();
        self.error = false;
        Some(Work {
            generation: self.generation,
            source,
            plan,
            destination,
            replace,
            control,
            movie_cancel,
            progress,
        })
    }
    pub fn finished(&mut self, generation: u64, result: Result<GifExportResult, GifError>) {
        if self.closed || generation != self.generation || self.job.is_none() {
            return;
        }
        let loops = self.job.take().is_some_and(|job| job.loops);
        match result {
            Ok(result) => {
                self.result_revision += 1;
                self.result_loops = loops;
                self.status = format!("Saved {} · {} bytes", result.path.file_name().unwrap_or_default().to_string_lossy(), result.file_size);
                self.result = Some(result);
            }
            Err(GifError::Cancelled) => self.status = "Conversion cancelled before publication. The source and any previous GIF are kept.".into(),
            Err(error) => { self.status = error.to_string(); self.error = true; }
        }
    }
    pub fn cancel(&mut self) {
        if let Some(job) = &self.job {
            job.movie_cancel.cancel();
            match job.control.cancel() {
                Ok(gif::CancelOutcome::AlreadyPublished) => {
                    self.status = "GIF was already saved; finishing…".into()
                }
                Ok(gif::CancelOutcome::PublicationClaimed) => {
                    self.status = "GIF publication already started; waiting for its result…".into()
                }
                Ok(gif::CancelOutcome::AlreadyFailed) => {
                    self.status = "GIF export failed; waiting for its result…".into()
                }
                Ok(gif::CancelOutcome::Cancelled) => self.status = "Cancelling conversion…".into(),
                Err(error) => {
                    self.status = error.to_string();
                    self.error = true;
                }
            }
        }
    }
    pub fn close(&mut self) {
        self.cancel();
        self.metadata_cancel.cancel();
        self.closed = true;
        self.selected = None;
        self.source = None;
        self.info = None;
        self.loading = false;
        self.generation += 1;
    }
}
impl Drop for Model {
    fn drop(&mut self) {
        self.close();
    }
}
impl Work {
    pub fn run(self) -> Result<GifExportResult, GifError> {
        self.control.check_active()?;
        let source = self.source.clone();
        match source {
            SelectedSource::Movie(selected) => self.run_movie(selected),
            SelectedSource::Recording(recording) => {
                recording
                    .0
                    .verify()
                    .map_err(|e| GifError::Source(e.to_string()))?;
                #[cfg(feature = "recording-fixtures")]
                if let Some(recipe) = recording.0.known_frames() {
                    if !recipe.is_bound_to(&recording.0) {
                        return Err(GifError::Source(
                            "Recording fixture identity changed.".into(),
                        ));
                    }
                    super::recording::fixture_hold_export(&self.movie_cancel)?;
                    let mut frames =
                        super::recording::KnownFramesSource::new(recipe, self.movie_cancel.clone());
                    return gif::export_gif(
                        &mut frames,
                        &self.plan,
                        Some(recording.0.path()),
                        &self.destination,
                        self.replace,
                        &self.control,
                        |written, _| {
                            self.progress.store(written, Ordering::Release);
                        },
                    );
                }
                self.run_movie(recording.0.selected_movie())
            }
            #[cfg(any(test, debug_assertions))]
            SelectedSource::Synthetic(_owner) => {
                fixture_delay("EXPORT", &self.movie_cancel).map_err(|_| GifError::Cancelled)?;
                gif::export_gif(
                    &mut SyntheticFrames(0),
                    &self.plan,
                    None,
                    &self.destination,
                    self.replace,
                    &self.control,
                    |written, _| {
                        self.progress.store(written, Ordering::Release);
                    },
                )
            }
        }
    }
    fn run_movie(self, selected: SelectedMovie) -> Result<GifExportResult, GifError> {
        let path = selected.path().to_owned();
        let asset = MovieAsset::open_selected(selected, self.movie_cancel).map_err(movie_error)?;
        let range =
            MovieReadRange::new(self.plan.start(), self.plan.end(), self.plan.frame_delay())
                .map_err(movie_error)?;
        let mut reader = NativeFrames(asset.reader(range).map_err(movie_error)?);
        gif::export_gif(
            &mut reader,
            &self.plan,
            Some(&path),
            &self.destination,
            self.replace,
            &self.control,
            |written, _| {
                self.progress.store(written, Ordering::Release);
            },
        )
    }
}

fn movie_error(error: bello_platform::movie::MovieError) -> GifError {
    if error == bello_platform::movie::MovieError::Cancelled {
        GifError::Cancelled
    } else {
        GifError::Source(error.to_string())
    }
}
struct NativeFrames(MovieReader);
impl SequentialFrameSource for NativeFrames {
    fn finish(&mut self, control: &ExportControl) -> Result<(), GifError> {
        self.0
            .finish(|| control.check_active().is_err())
            .map_err(movie_error)
    }
    fn next_frame(
        &mut self,
        control: &ExportControl,
    ) -> Result<Option<gif::DisplayRgbaFrame>, GifError> {
        self.0
            .next_frame(|| control.check_active().is_err())
            .map_err(movie_error)?
            .map(|frame| {
                let (pts, width, height, pixels) = frame.into_parts();
                gif::DisplayRgbaFrame::new(pts, width, height, pixels)
            })
            .transpose()
    }
}
#[cfg(any(test, debug_assertions))]
struct SyntheticFrames(usize);
#[cfg(any(test, debug_assertions))]
impl SequentialFrameSource for SyntheticFrames {
    fn next_frame(
        &mut self,
        control: &ExportControl,
    ) -> Result<Option<gif::DisplayRgbaFrame>, GifError> {
        control.check_active()?;
        if self.0 >= 60 {
            return Ok(None);
        }
        let index = self.0;
        self.0 += 1;
        gif::DisplayRgbaFrame::new(index as f64 / 20., 320, 180, synthetic_pixels(index)).map(Some)
    }
}
#[cfg(any(test, debug_assertions))]
fn synthetic_pixels(index: usize) -> Vec<u8> {
    let mut pixels = vec![0; 320 * 180 * 4];
    for (position, pixel) in pixels.as_chunks_mut::<4>().0.iter_mut().enumerate() {
        let x = position % 320;
        let y = position / 320;
        // Time marker moves across the source; final half-second is magenta and
        // intentionally excluded by early-trim sentinel acceptance tests.
        pixel.copy_from_slice(&if index >= 50 {
            [255, 0, 255, 255]
        } else {
            [
                if x < index * 320 / 60 { 230 } else { 40 },
                if y < 90 { 130 } else { 60 },
                180,
                255,
            ]
        });
    }
    pixels
}

/// Exact paired-slider coupling from GIFTrimControls, including its 0.1s UI minimum.
pub(super) fn move_trim(
    options: &mut GifExportOptions,
    duration: f64,
    start_handle: bool,
    value: f64,
) {
    if !duration.is_finite() || !value.is_finite() {
        return;
    }
    let total = duration.max(0.1);
    if start_handle {
        let current_end = options.trim_end.unwrap_or(total).min(total);
        let length = (current_end - options.trim_start).max(0.1);
        let start = value.clamp(0., total - 0.1);
        let mut end = current_end;
        if end < start + 0.1 {
            end = total.min(start + length);
        }
        if end - start > 120. {
            end = start + 120.;
        }
        options.trim_start = start;
        options.trim_end = Some(end);
    } else {
        let end = value.clamp(0.1, total);
        let mut start = options.trim_start;
        if start > end - 0.1 {
            start = (end - 0.1).max(0.);
        }
        if end - start > 120. {
            start = end - 120.;
        }
        options.trim_start = start;
        options.trim_end = Some(end);
    }
}
pub(super) fn open_preview(result: &GifExportResult) -> Result<gif::GifPreview, GifError> {
    #[cfg(unix)]
    {
        use std::os::unix::fs::OpenOptionsExt;
        let file = std::fs::OpenOptions::new()
            .read(true)
            .custom_flags(libc::O_NONBLOCK | libc::O_NOFOLLOW)
            .open(&result.path)?;
        gif::GifPreview::open(file, result)
    }
    #[cfg(not(unix))]
    {
        let _ = result;
        Err(GifError::UnsupportedFilesystem)
    }
}
